import ActivityGenerator from "@/components/ActivityGenerator";

export default function Home() {
  return (
    <div className="bg-gray-50 min-h-screen font-sans text-gray-800 flex items-center justify-center p-4">
      <div className="max-w-md w-full mx-auto">
        <ActivityGenerator />
      </div>
    </div>
  );
}
