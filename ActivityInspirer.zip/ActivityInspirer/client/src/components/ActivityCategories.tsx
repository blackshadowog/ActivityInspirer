import { Button } from "@/components/ui/button";

interface ActivityCategoriesProps {
  currentCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function ActivityCategories({ currentCategory, onCategoryChange }: ActivityCategoriesProps) {
  const categories = [
    { id: "easy", label: "Easy", bgColor: "bg-secondary/10", textColor: "text-secondary", hoverColor: "hover:bg-secondary/20" },
    { id: "outdoor", label: "Outdoor", bgColor: "bg-success/10", textColor: "text-success", hoverColor: "hover:bg-success/20" },
    { id: "dare", label: "Dares", bgColor: "bg-accent/10", textColor: "text-accent", hoverColor: "hover:bg-accent/20" },
    { id: "all", label: "All Activities", bgColor: "bg-primary/10", textColor: "text-primary", hoverColor: "hover:bg-primary/20" }
  ];

  return (
    <div className="mt-8 flex flex-wrap justify-center gap-2">
      {categories.map(category => (
        <button
          key={category.id}
          className={`${category.bgColor} ${category.textColor} ${category.hoverColor} px-3 py-1 rounded-full text-sm font-medium transition-colors ${
            currentCategory === category.id ? "bg-opacity-30 font-semibold" : ""
          }`}
          onClick={() => onCategoryChange(category.id)}
        >
          {category.label}
        </button>
      ))}
    </div>
  );
}
