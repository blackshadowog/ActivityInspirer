import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Activity } from "@shared/schema";
import ActivityDisplay from "./ActivityDisplay";
import ActivityCategories from "./ActivityCategories";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function ActivityGenerator() {
  const [currentActivity, setCurrentActivity] = useState<string>("Ready for an activity suggestion?");
  const [activityCounter, setActivityCounter] = useState<number>(0);
  const [currentCategory, setCurrentCategory] = useState<string>("all");
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
  const [lastActivity, setLastActivity] = useState<string>("");

  // Fetch activities
  const { data: activities, isLoading, error } = useQuery<Activity[]>({
    queryKey: [currentCategory === 'all' ? '/api/activities' : `/api/activities/category/${currentCategory}`],
  });

  // Function to generate a random activity
  const generateActivity = () => {
    if (!activities || activities.length === 0 || isAnimating) return;
    
    setIsAnimating(true);
    
    // Get a random activity that's not the same as the last one
    let randomActivity: Activity;
    let activityText: string;
    
    if (activities.length === 1) {
      randomActivity = activities[0];
      activityText = randomActivity.text;
    } else {
      do {
        const randomIndex = Math.floor(Math.random() * activities.length);
        randomActivity = activities[randomIndex];
        activityText = randomActivity.text;
      } while (activityText === lastActivity && activities.length > 1);
    }
    
    setLastActivity(activityText);
    
    // Update the counter
    setActivityCounter(prev => prev + 1);
    
    // Set the new activity after a short delay to allow for the fade-out animation
    setTimeout(() => {
      setCurrentActivity(activityText);
      setIsAnimating(false);
    }, 300);
  };

  if (error) {
    return (
      <div className="text-center p-8">
        <p className="text-red-500">Failed to load activities. Please try again later.</p>
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold text-primary mb-2">Random Activity Generator</h1>
        <p className="text-gray-600">Press the button to discover something fun to do!</p>
      </header>

      {/* Activity Card */}
      <div className="bg-white rounded-xl shadow-md p-6 md:p-8">
        {/* Activity Display */}
        <ActivityDisplay 
          activity={currentActivity} 
          isAnimating={isAnimating} 
          isLoading={isLoading}
        />

        {/* Generate Button */}
        <div className="flex justify-center">
          <Button
            onClick={generateActivity}
            disabled={isLoading || isAnimating || !activities || activities.length === 0}
            className="bg-primary hover:bg-primary/90 text-white font-medium py-3 px-8 rounded-lg text-lg transition-all duration-200 shadow-md hover:shadow-lg flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary h-auto"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading...
              </>
            ) : (
              <span>Give Me Something To Do!</span>
            )}
          </Button>
        </div>

        {/* Activity Counter */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500">
            You've generated {activityCounter} {activityCounter === 1 ? 'activity' : 'activities'}
          </p>
        </div>
      </div>

      {/* Activity Categories */}
      <ActivityCategories 
        currentCategory={currentCategory} 
        onCategoryChange={setCurrentCategory} 
      />

      {/* Footer */}
      <footer className="mt-12 text-center text-gray-500 text-sm">
        <p>Made for fun and inspiration</p>
      </footer>
    </>
  );
}
