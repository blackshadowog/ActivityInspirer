import { Skeleton } from "@/components/ui/skeleton";

interface ActivityDisplayProps {
  activity: string;
  isAnimating: boolean;
  isLoading: boolean;
}

export default function ActivityDisplay({ 
  activity, 
  isAnimating,
  isLoading 
}: ActivityDisplayProps) {
  if (isLoading) {
    return (
      <div className="activity-box mb-8 min-h-[100px] flex items-center justify-center">
        <Skeleton className="h-8 w-4/5" />
      </div>
    );
  }

  return (
    <div className="activity-box mb-8 min-h-[100px] flex items-center justify-center">
      <p
        className={`text-xl md:text-2xl font-medium text-center transition-opacity duration-300 ${
          isAnimating ? "opacity-0" : "opacity-100"
        }`}
      >
        {activity}
      </p>
    </div>
  );
}
