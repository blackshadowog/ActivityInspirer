import { users, type User, type InsertUser, activities, type Activity, type InsertActivity } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Activity related methods
  getActivities(): Promise<Activity[]>;
  getActivitiesByCategory(category: string): Promise<Activity[]>;
  getActivity(id: number): Promise<Activity | undefined>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private activities: Map<number, Activity>;
  private currentUserId: number;
  private currentActivityId: number;

  constructor() {
    this.users = new Map();
    this.activities = new Map();
    this.currentUserId = 1;
    this.currentActivityId = 1;
    
    // Initialize with default activities
    const defaultActivities: InsertActivity[] = [
      { text: "Go for a walk", category: "outdoor" },
      { text: "Try a new recipe", category: "easy" },
      { text: "Call a friend", category: "easy" },
      { text: "Do 10 jumping jacks", category: "dare" },
      { text: "Draw a self-portrait", category: "easy" },
      { text: "Learn 5 words in a new language", category: "easy" },
      { text: "Meditate for 5 minutes", category: "easy" },
      { text: "Write a short poem", category: "easy" },
      { text: "Take a nature photo", category: "outdoor" },
      { text: "Send a nice message to someone", category: "easy" },
      { text: "Do a random act of kindness", category: "easy" },
      { text: "Sing your favorite song out loud", category: "dare" },
      { text: "Dance like nobody's watching", category: "dare" },
      { text: "Tell a joke to the next person you see", category: "dare" },
      { text: "Go for a bike ride", category: "outdoor" },
      { text: "Try a 1-minute plank", category: "dare" },
      { text: "Write down three things you're grateful for", category: "easy" },
      { text: "Drink a full glass of water", category: "easy" },
      { text: "Stretch for 5 minutes", category: "easy" },
      { text: "Take a different route home", category: "outdoor" }
    ];
    
    defaultActivities.forEach(activity => {
      this.createActivity(activity);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async getActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values());
  }
  
  async getActivitiesByCategory(category: string): Promise<Activity[]> {
    return Array.from(this.activities.values()).filter(
      (activity) => activity.category === category,
    );
  }
  
  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }
  
  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = { ...insertActivity, id };
    this.activities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();
